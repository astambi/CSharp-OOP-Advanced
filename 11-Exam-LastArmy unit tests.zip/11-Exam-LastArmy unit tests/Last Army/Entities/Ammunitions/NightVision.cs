﻿public class NightVision : Ammunition
{
    public const double WeightConst = 0.8;

    public NightVision(string name)
        : base(name, WeightConst)
    {
    }
}