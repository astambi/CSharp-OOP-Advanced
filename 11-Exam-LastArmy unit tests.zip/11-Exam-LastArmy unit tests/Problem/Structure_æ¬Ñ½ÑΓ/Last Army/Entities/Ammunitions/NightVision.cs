﻿namespace Last_Army
{
    public class NightVision
    {
        public const double Weight = 0.8;

        public NightVision(string name)
            : base (name, Weight)
        {
        }
    }
}