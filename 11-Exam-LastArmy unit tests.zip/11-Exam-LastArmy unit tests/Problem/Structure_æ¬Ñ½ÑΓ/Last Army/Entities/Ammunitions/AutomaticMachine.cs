﻿public class AutomaticMachine : Ammunition
{
    public const double Weight = 6.3;

    public AutomaticMachine(string name)
        : base(name, Weight)
    {
    }
}