﻿namespace Last_Army
{
    public class Knife
    {
        public const double Weight = 0.4;

        public Knife(string name)
            : base (name, Weight)
        {
        }
    }
}