﻿namespace Last_Army
{
    public class BulletproofVest
    {
        public const double Weight = 3.4;

        public BulletproofVest(string name)
            : base(name, Weight)
        {
        }
    }
}