﻿namespace E07_FoodShortage.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}