﻿namespace E07_FoodShortage.Models
{
    public interface IBirthdate
    {
        string BirthDate { get; }
    }
}