﻿namespace RecyclingStation.Interfaces.UI
{
    public interface IReader
    {
        string ReadLine();
    }
}
