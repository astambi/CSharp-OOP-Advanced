﻿namespace RecyclingStation.Interfaces.UI
{
    public interface IWriter
    {
        void WriteLine(string message);
    }
}
