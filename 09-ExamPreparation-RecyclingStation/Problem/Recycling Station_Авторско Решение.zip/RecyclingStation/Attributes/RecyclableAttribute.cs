﻿namespace RecyclingStation.Attributes
{
    using RecyclingStation.WasteDisposal.Attributes;

    public class RecyclableAttribute : DisposableAttribute
    {
    }
}
