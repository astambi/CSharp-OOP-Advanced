﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecyclingStation.Tests.MockedObjects
{
    using RecyclingStation.WasteDisposal.Attributes;

    public class ThirdMockedDisposableAttribute : DisposableAttribute
    {
    }
}
