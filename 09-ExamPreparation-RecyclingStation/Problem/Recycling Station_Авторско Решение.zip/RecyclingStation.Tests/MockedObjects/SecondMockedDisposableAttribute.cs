﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecyclingStation.WasteDisposal.Attributes;

namespace RecyclingStation.Tests.MockedObjects
{
    public class SecondMockedDisposableAttribute : DisposableAttribute
    {
    }
}
