﻿namespace RecyclingStation.WasteDisposal
{
    using System;
    using System.Collections.Generic;
    using RecyclingStation.WasteDisposal.Interfaces;

    internal class StrategyHolder : IStrategyHolder
    {
        private readonly IDictionary<Type, IGarbageDisposalStrategy> strategies;

        public StrategyHolder(Dictionary<Type, IGarbageDisposalStrategy> strategies)
        {
            this.strategies = strategies;
        }

        // fixed
        //public StrategyHolder()
        //{
        //    this.strategies = new Dictionary<Type, IGarbageDisposalStrategy>();
        //}

        public IReadOnlyDictionary<Type, IGarbageDisposalStrategy> GetDisposalStrategies
        {
            get
            {
                return (IReadOnlyDictionary<Type, IGarbageDisposalStrategy>)this.strategies;
            }
        }

        // fixed
        public bool AddStrategy(Type disposableAttribute, IGarbageDisposalStrategy strategy)
        {
            //this.strategies.Add(disposableAttribute, strategy);
            //return true;

            // fixed
            if (!this.strategies.ContainsKey(disposableAttribute))
            {
                this.strategies.Add(disposableAttribute, strategy);
                return true;
            }
            return false;
        }

        // fixed
        public bool RemoveStrategy(Type disposableAttribute)
        {
            //this.strategies.Remove(disposableAttribute);
            //return true;

            // fixed
            if (this.strategies.ContainsKey(disposableAttribute))
            {
                this.strategies.Remove(disposableAttribute);
                return true;
            }
            return false;
        }
    }
}
