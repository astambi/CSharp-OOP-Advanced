﻿namespace RecyclingStation.BusinessLayer.Contracts.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
