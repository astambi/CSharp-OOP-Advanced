﻿namespace RecyclingStation.BusinessLayer.Contracts.Core
{
    public interface IEngine
    {
        void Run();
    }
}
