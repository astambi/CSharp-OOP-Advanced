﻿namespace E09_TrafficLights
{
    public enum LightColor
    {
        Red, 
        Green,
        Yellow
    }
}
