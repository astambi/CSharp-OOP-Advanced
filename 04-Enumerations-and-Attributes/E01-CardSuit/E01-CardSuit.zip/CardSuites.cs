﻿namespace E01_CardSuit
{
    public enum CardSuites
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
