﻿// New
public interface IGameController
{
    void ProcessInput(string input);

    void RequestFinalSummary();
}
