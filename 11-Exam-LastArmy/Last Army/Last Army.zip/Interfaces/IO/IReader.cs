﻿// New
public interface IReader
{
    string ReadLine();
}