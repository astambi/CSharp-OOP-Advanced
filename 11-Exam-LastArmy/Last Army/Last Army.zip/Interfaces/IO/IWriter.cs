﻿// New
public interface IWriter
{
    void AppendMessage(string message);

    void WriteMessages();
}