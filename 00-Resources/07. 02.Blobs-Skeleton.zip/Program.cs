﻿namespace _02.Blobs
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
