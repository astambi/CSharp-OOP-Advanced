﻿namespace _02.Blobs.Interfaces
{
    public interface IBehavior
    {
        
    }
}