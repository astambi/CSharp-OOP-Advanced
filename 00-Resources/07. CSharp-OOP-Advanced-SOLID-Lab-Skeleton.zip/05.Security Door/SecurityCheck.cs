﻿namespace _05.Security_Door
{
    public abstract class SecurityCheck
    {
        public abstract bool ValidateUser();
    }
}