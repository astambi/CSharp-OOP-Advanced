﻿namespace _05.Security_Door
{
    public interface ISecurityUI
    {
        string RequestKeyCard();

        int RequestPinCode();
    }
}