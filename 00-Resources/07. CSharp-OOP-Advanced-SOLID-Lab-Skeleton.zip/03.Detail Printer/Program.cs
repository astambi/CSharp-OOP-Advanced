﻿namespace _03.Detail_Printer
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
