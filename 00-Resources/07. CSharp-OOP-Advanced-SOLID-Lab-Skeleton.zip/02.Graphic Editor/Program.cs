﻿namespace _02.Graphic_Editor
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
