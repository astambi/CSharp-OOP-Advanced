﻿namespace _02.Graphic_Editor
{
    public class Square : IShape
    {
        
    }
}