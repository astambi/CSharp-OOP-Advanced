﻿using System.Collections.Generic;

public interface ICommand
{
    //IManager Manager { get; }

    //IList<string> ArgsList { get; }

    string Execute();
}