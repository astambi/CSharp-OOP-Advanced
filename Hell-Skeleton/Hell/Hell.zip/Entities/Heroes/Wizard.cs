﻿public class Wizard : AbstractHero
{
    public Wizard(string name)
        : base(name, 25, 25, 100, 100, 250)
    {
    }
}
